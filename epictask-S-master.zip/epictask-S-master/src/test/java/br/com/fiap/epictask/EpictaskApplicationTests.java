package br.com.fiap.epictask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpictaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
